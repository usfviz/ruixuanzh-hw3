library(ggplot2)

facebook <- read.csv("Facebook_metrics/dataset_Facebook.csv", sep = ";")
facebook[is.na(facebook)] <- 1
heatdf <- subset(facebook, select = -c(Type))


p <-ggplot(heatdf, aes_string("Post.Weekday", "Post.Hour", fill= "comment")) +
  geom_tile(color= "white",size=0.1) + 
  scale_fill_viridis(name="comment",option ="C")
p <-p + facet_grid(reformulate("Post.Month","Category"))
p <-p + scale_y_continuous(trans = "reverse", breaks = unique(heatdf["Post.Hour"])
p <-p + scale_x_continuous(breaks =c(1,3,5,7))
p <-p + theme_minimal(base_size = 8)
p <-p + labs(title= "Hourly comment", x="Day", y="Hour")
p <-p + theme(legend.position = "bottom")+
  theme(plot.title=element_text(size = 14))+
  theme(axis.text.y=element_text(size=6)) +
  theme(strip.background = element_rect(colour="white"))+
  theme(plot.title=element_text(hjust=0))+
  theme(axis.ticks=element_blank())+
  theme(axis.text=element_text(size=7))+
  theme(legend.title=element_text(size=8))+
  theme(legend.text=element_text(size=6))+
  removeGrid()
p
